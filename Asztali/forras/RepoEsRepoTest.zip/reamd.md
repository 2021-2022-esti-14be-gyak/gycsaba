Asztali alkalmazás
